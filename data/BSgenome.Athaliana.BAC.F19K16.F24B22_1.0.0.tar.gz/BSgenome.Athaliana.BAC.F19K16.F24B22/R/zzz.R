###
###

.pkgname <- "BSgenome.Athaliana.BAC.F19K16.F24B22"

.seqnames <- NULL

.circ_seqs <- character(0)

.mseqnames <- NULL

.onLoad <- function(libname, pkgname)
{
    if (pkgname != .pkgname)
        stop("package name (", pkgname, ") is not ",
             "the expected name (", .pkgname, ")")
    extdata_dirpath <- system.file("extdata", package=pkgname,
                                   lib.loc=libname, mustWork=TRUE)

    ## Make and export BSgenome object.
    bsgenome <- BSgenome(
        organism="Arabidopsis thaliana",
        common_name="Thale cress",
        genome="BAC.F19K16.F24B22",
        provider="TAIR",
        release_date="2010-11-18",
        source_url="https://www.arabidopsis.org/servlets/TairObject?type=assembly_unit&id=362; https://www.arabidopsis.org/servlet/TairObject?type=AssemblyUnit&name=F24B22",
        seqnames=.seqnames,
        circ_seqs=.circ_seqs,
        mseqnames=.mseqnames,
        seqs_pkgname=pkgname,
        seqs_dirpath=extdata_dirpath
    )

    ns <- asNamespace(pkgname)

    objname <- pkgname
    assign(objname, bsgenome, envir=ns)
    namespaceExport(ns, objname)

    old_objname <- "Athaliana"
    assign(old_objname, bsgenome, envir=ns)
    namespaceExport(ns, old_objname)
}

